// Task 3

window.onload = startUp;

function startUp(){
    let  file = document.getElementById("file");
    file.onchange=handleFile;
}
// this function i use it to upload the file and convert it to 2d Array
function handleFile(event){

    let file = event.target.files[0];
    let filereader = new FileReader();
    filereader.readAsText(file);
    filereader.onload = twoD;
    function twoD(){

        let lines = filereader.result.split("\n");
        for (var i = 0; i < lines.length; i++) {
            lines[i] = lines[i].split(",");
        }

        locationSelector(lines);
        locationCounter(lines);

    }
}
// this function will calcute  the total amount for each location in order to use that after in the drawStatistics function
function locationCounter(array) {
    var summing = [];
    let osMount = 0;
    let haMount = 0;
    let freMount = 0;
    let staMount = 0;
    for (let i = 0; i < array.length; i++) {
        if (array[i][2] == "Oslo") {
            osMount += parseInt(array[i][3]);
        } else if (array[i][2] == "Halden") {
            haMount += parseInt(array[i][3]);
        } else if (array[i][2] == "Fredrikstad") {
            freMount += parseInt(array[i][3]);
        } else {
            staMount += parseInt(array[i][3]);
        }
    }
    summing.push(new Array("Oslo", osMount), new Array("Halden", haMount), new Array("Fredrikstad", freMount), new Array("Stavanger", staMount));
    drawStatistics(summing);
}

// this function i use it to draw the bar in canvas
    function drawStatistics(data) {
        let canvas = document.getElementById("myCanvas");
        let context = canvas.getContext("2d");
        let indent = canvas.width / (data.length + 1);
        let xPosition = indent;
        let total = 0;

        context.font = "18px monospace";

        // Find total amount
        data.forEach(stat => {
            total += stat[1];
        });

        // Create bars
        data.forEach(stat => {
            let height = canvas.height * (stat[1] / total);

            context.fillStyle = "#1e1e1e";
            context.fillText(stat[0], xPosition - (stat[0].length * 3), canvas.height - 10);

            context.fillRect(xPosition, canvas.height - height - 40, 15, height);
            xPosition += indent;
        });
    }
