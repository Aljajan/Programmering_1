

// Task 3

window.onload = startUp;

function startUp(){
    let  file = document.getElementById("file");
    file.onchange=handleFile;
}
// this function i use it to upload the file and convert it to 2d Array
function handleFile(event){

    let file = event.target.files[0];
    let filereader = new FileReader();
    filereader.readAsText(file);
    filereader.onload = twoD;
    function twoD(){

        let lines = filereader.result.split("\n");
        for (var i = 0; i < lines.length; i++) {
            lines[i] = lines[i].split(",");
        }

        locationSelector(lines);
        locationCounter(lines);

    }
}
// this function will calcute  the total amount for each location in order to use that after in the drawStatistics function
function locationCounter(array) {
    var summing = [];
    let osMount = 0;
    let haMount = 0;
    let freMount = 0;
    let staMount = 0;
    for (let i = 0; i < array.length; i++) {
        if (array[i][2] == "Oslo") {
            osMount += parseInt(array[i][3]);
        } else if (array[i][2] == "Halden") {
            haMount += parseInt(array[i][3]);
        } else if (array[i][2] == "Fredrikstad") {
            freMount += parseInt(array[i][3]);
        } else {
            staMount += parseInt(array[i][3]);
        }
    }
    summing.push(new Array("Oslo", osMount), new Array("Halden", haMount), new Array("Fredrikstad", freMount), new Array("Stavanger", staMount));
    drawStatistics(summing);
}

// this function i use it to draw the bar in canvas
    function drawStatistics(data) {
        let canvas = document.getElementById("myCanvas");
        let context = canvas.getContext("2d");
        let indent = canvas.width / (data.length + 1);
        let xPosition = indent;
        let total = 0;

        context.font = "18px monospace";

        // Find total amount
        data.forEach(stat => {
            total += stat[1];
        });

        // Create bars
        data.forEach(stat => {
            let height = canvas.height * (stat[1] / total);

            context.fillStyle = "#1e1e1e";
            context.fillText(stat[0], xPosition - (stat[0].length * 3), canvas.height - 10);

            context.fillRect(xPosition, canvas.height - height - 40, 15, height);
            xPosition += indent;
        });
    }
// Task 4
// this function will in order to query transactions by Location and summarize them using the minimum/maximum and average amount.
function locationSelector (array) {

    let osMount = [];
    let osTotal = 0;
    let haMount = [];
    let haTotal = 0;
    let frMount = [];
    let frTotal = 0;
    let stMount = [];
    let stTotal = 0;

    document.getElementById("selector").onchange = function () {
        let selecte = this.value;
        if (selecte == "Oslo") {
            let osTable1 = [];
            let osTable2 = [];
            for (let i = 0; i < array.length; i++) {
                if (array[i][2] == "Oslo") {
                    osMount.push(array[i][3]);
                    osTable1.push([array[i][0], array[i][1], array[i][3]]);
                    osTotal += parseInt(array[i][3]);
                }
            }
            let osmaximum = Math.max.apply(null, osMount);
            let osminimum = Math.min.apply(null, osMount);
            let oslength = osMount.length;
            let osAvreage = parseInt(osTotal / oslength);
            osTable1.unshift(["Date", "Type", "Amount"]);
            osTable2.push(["Minimum", "Maximum", "Average"], [osminimum, osmaximum, osAvreage]);
            presenttable1(osTable1);
            presenttable2(osTable2);

        } else if (selecte == "Halden") {
            let haTable1 = [];
            let haTable2 = [];
            for (let i = 0; i < array.length; i++) {
                if (array[i][2] == "Halden") {
                    haMount.push(array[i][3]);
                    haTable1.push([array[i][0], array[i][1], array[i][3]]);
                    haTotal += parseInt(array[i][3]);
                }
            }
            let hamaximum = Math.max.apply(null, haMount);
            let haminimum = Math.min.apply(null, haMount);
            let halength = haMount.length;
            let haAvreage = parseInt(haTotal / halength);
            haTable1.unshift(["Date", "Type", "Amount"]);
            haTable2.push(["Minimum", "Maximum", "Average"], [haminimum, hamaximum, haAvreage]);
            presenttable1(haTable1);
            presenttable2(haTable2);

        } else if (selecte == "Fredrikstad") {
            let frTable1 = [];
            let frTable2 = [];
            for (let i = 0; i < array.length; i++) {
                if (array[i][2] == "Fredrikstad") {
                    frMount.push(array[i][3]);
                    frTable1.push([array[i][0], array[i][1], array[i][3]]);
                    frTotal += parseInt(array[i][3]);
                }
            }
            let frmaximum = Math.max.apply(null, frMount);
            let frminimum = Math.min.apply(null, frMount);
            let frlength = frMount.length;
            let frAvreage = parseInt(frTotal / frlength);
            frTable1.unshift(["Date", "Type", "Amount"]);
            frTable2.push(["Minimum", "Maximum", "Average"], [frminimum, frmaximum, frAvreage]);
            presenttable1(frTable1);
            presenttable2(frTable2);
        } else {
            let stTable1 = [];
            let stTable2 = [];
            for (let i = 0; i < array.length; i++) {
                if (array[i][2] == "Stavanger") {
                    stMount.push(array[i][3]);
                    stTable1.push([array[i][0], array[i][1], array[i][3]]);
                    stTotal += parseInt(array[i][3]);
                }
            }
            let stmaximum = Math.max.apply(null, stMount);
            let stminimum = Math.min.apply(null, stMount);
            let stlength = stMount.length;
            let stAvreage = parseInt(stTotal / stlength);
            stTable1.unshift(["Date", "Type", "Amount"]);
            stTable2.push(["Minimum", "Maximum", "Average"], [stminimum, stmaximum, stAvreage]);
            presenttable1(stTable1);
            presenttable2(stTable2);
        }

    }
}


// Task 5
// function which will show the first table In HTML
        function presenttable1(array){
            let table1 = document.getElementById("table1");
            table1.innerHTML="";

            for (let i = 0; i < array.length; i++) {
                let row = table1.insertRow(-1);
                let cells = array[i];
                for (let j = 0; j < cells.length; j++) {
                    let cell = row.insertCell(-1);
                    cell.innerHTML = cells[j];

                }

            }


        }

        //   function will show the second table in HTML
        function presenttable2(array) {
            let table2 = document.getElementById("table2");
            table2.innerHTML = "";

            for (let i = 0; i < array.length; i++) {
                let row = table2.insertRow(-1);
                let cells = array[i];
                for (let j= 0; j < cells.length; j++) {
                    let cell = row.insertCell(-1);
                    cell.innerHTML = cells[j];

                }

            }

        }






