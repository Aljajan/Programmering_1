window.onload = startup;
function startup() 
{
   document.getElementById("Button1").addEventListener("click",christmasTree);
}


function christmasTree() {

var a =document.getElementById('a').value;
var b=document.getElementById('b').value; 

    var line = parseInt(b);
    var length = line * 2 - 1;
    var spaces = (length - 1) / 2;
    for ( var i = 0; i < line ; i++ ) {
        var star = a;
        var space = ' ';

        for ( var j = 1; j <= i; j++ ) {
            star = star +( a+a);            
        }
           
        var spacesBefore = space.repeat(line-i-1);
        star = spacesBefore + star;
        console.log('\033[32m' +star);
    }
}