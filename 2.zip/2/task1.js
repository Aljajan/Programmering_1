window.onload = startup;
var z = [];
function startup() 
{
   document.getElementById("add").addEventListener("click",add);
   document.getElementById("del").addEventListener("click",del);
   document.getElementById("undo").addEventListener("click",undo);
}

function showListInfo() {
var res = "";
var res2 = ""
for (var i = 0; i < z.length; i++) 
{
     res=res + z[i] + ' * ' ;
     res2=res2 + "The element is '" + z[i] + "' its index is '"
    + i + "'" + "</br>" ;
 }
    document.getElementById("list").innerHTML="<h4 style='color:lightskyblue;'>The elemnts of your list :</h4>" + res;
    var mid;
     if (z.length % 2==1 && z.length> 1) 
     {
    mid = z[((z.length + 1) / 2) - 1];
    }
    else
    mid = "";

    var p = "<h4 style='color:lightskyblue;'>Some info about your list :</h4>" +
    "The first element of your list is " + z[0] + "</br>"
    + "The last element of your list is " + z[z.length - 1] + "</br>"
    + "The count of your list elements is " + z.length + "</br>" +
    "The middle element of your list is " + mid;

    document.getElementById("info").innerHTML =p;
    document.getElementById("infoIndexes").innerHTML =
    "<h4 style='color:lightskyblue;'>The elements and there indexes :</h4>" + res2;
}
    function del()
     {
        var index = document.getElementById("index");
        var x=index.value;
    if (z.length < 1 || x=="" ||x>=z.length || x<0)
     alert("Sorry,There is no elements in the list to delete"); 
                 else if (x !="" )
                  {
                       z.splice(x, 1); 
                       showListInfo(); 
                    }
                 } 
            function add() { 
                var b = document.getElementById("b");
                var x=b.value;
                if (x !="" ) 
                {
                     z.push(x); 
                     showListInfo(); } 
                else 
                alert("Please enter an element to add it to your list") ;
              
        }
        function undo()
         { 
            {   z.pop();
                showListInfo(); 
               }
          
         }
        