
window.onload=calcCircleAreaByRadius;
function calcCircleAreaByRadius(r) {

    var area;
    if (Number.isInteger(parseInt(r)) == true & parseInt(r) > 0) {
        area = Math.pow(r, 2) * Math.PI;
    }
    else {
        area = undefined;

    }
    return area;

}
//Press f12 to show console window 
console.log("The area for the circle with radius=1 is: \n");
console.log(calcCircleAreaByRadius(1));
console.log("The area for the circle with radius=8 is: \n");
console.log(calcCircleAreaByRadius(8));
console.log("The area for the circle with radius='fifteen' is: \n");
console.log(calcCircleAreaByRadius('fifteen'));
console.log("The area for the circle with radius=-4 is: \n");
console.log(calcCircleAreaByRadius(-4));
