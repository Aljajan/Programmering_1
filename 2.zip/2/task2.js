window.onload = startup;
function startup() 
{
   document.getElementById("signIn").addEventListener("click",check);
}

function checkCaseSensetave() {
    var p = document.getElementById("p").value;
    var i = 0;
    var l = p.split('');
    var c = [];
    var checked = false;
    c = l;
    for (i = 0; i < c.length; i++) {

        if ((l[i]) == (l[i]).toUpperCase()) {
            checked = true;
            break;
        }
    }
    if (checked == true) {
        for (k = 0; k < c.length; k++) {
            if ((l[k]) == (l[k]).toLowerCase()) {
                checked = true;
                break;
            }
        }
    }
    return checked;
}

function hasCharacters() {
    var p = document.getElementById("p").value;
    var x = false;
    x = p.match("^[a-zA-Z]");
    return x;
}
function specialCharacter() {
    var p = document.getElementById("p").value;
    var format = '/&^%$#@_+-*.,;[]{}=/';
    var n = false;
    var arr = format.split('');
    var specialChar = [];
    specialChar = arr;
    for (j = 0; j < specialChar.length; j++) {
        if (p.indexOf(specialChar[j]) > -1) {
            n = true;
            break;
        }
    }
    return n;
}
function hasNumber() {
    var p = document.getElementById("p").value;
    var x = false;
    x = p.match(/\d+/g);
    return x;
}

function check() {
    var p = document.getElementById("p").value;
    var u = document.getElementById("u").value;
    if (!(u == p) && (specialCharacter(p) == true) && (checkCaseSensetave(p) == true) && (p.length >= 8) && (p.length <= 32) && (hasCharacters(p) != null) && (hasNumber(p) != null)) {
        alert(u + " You are welcome to our web site");
        document.getElementById('result').innerHTML  = "  <h5 style=color:lightblue > Now you are logged in to our web site as " +u;
    }
    else {
        alert("Please enter a password that contains: \n 1- at least one number \n 2-upperCase character \n 3-lowercase character \n 4-one special character \n 5-it must be not equal to the user name value");
  document.getElementById('result').innerHTML  = "  <h6 style=color:red > sorry enter correct username and password to sign in";
    }


}