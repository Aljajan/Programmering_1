window.onload = startup;
function startup() 
{
   document.getElementById("Button1").addEventListener("click",xor);
   document.getElementById("Button2").addEventListener("click",xor1);
}

function xor() {
  var a= document.getElementById('a').value;
  var b= document.getElementById('b').value;
    var result ;
   if((parseInt(a)==0 || parseInt(a)==1 && (parseInt(b)==0 ||parseInt(b)==1)))
   
   {
       var res;

    if (a == 1)
     a = true;
    if (a == 0)
     a = false;
    if (b == 1)
     b = true;
     if (b == 0)
     b = false;
    res=(a || b) && !(a && b);
     document.getElementById('result').innerHTML= "The result is: "+  res;

}

else alert("Please input 0 or 1");}




function xor1() {
    var a=  document.getElementById('a').value;
    var b=   document.getElementById('b').value;
    var result ;
   if((parseInt(a)==0 || parseInt(a)==1 && (parseInt(b)==0 ||parseInt(b)==1)))
   
   {
       var res;

    if (a == 1)
     a = true;
    if (a == 0)
     a = false;
    if (b == 1)
     b = true;
     if (b == 0)
     b = false;
    res=(a || b) && (!a || !b);
     document.getElementById('result').innerHTML= "The result is: "+  res;

}

else alert("Please input 0 or 1");}

    



