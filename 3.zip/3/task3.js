window.onload = startUp;

function startUp(){
    let  file = document.getElementById("file");
    file.onchange=handleFile;
}

function handleFile(event) {

    let file = event.target.files[0];
    let filereader = new FileReader();
    filereader.readAsText(file);
    filereader.onload = twoD;

    function twoD() {

        let lines = filereader.result.split("\n");
        for (var i = 0; i < lines.length; i++) {
            lines[i] = lines[i].split(",");
        }
        console.table(lines);
    }
}
