window.onload = startUp;

function startUp(){
    let  file = document.getElementById("file");
    file.onchange=handleFile;
}

function handleFile(event) {

    let file = event.target.files[0];
    let filereader = new FileReader();
    filereader.readAsText(file);
    filereader.onload = twoD;

    function twoD() {
filereader.toString();

        console.log(filereader);
    }
}
