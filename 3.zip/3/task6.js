window.onload = startUp;

function startUp(){
    let  file = document.getElementById("file");
    file.onchange=handleFile;
}

function handleFile(event){

    let file = event.target.files[0];
    let filereader = new FileReader();
    filereader.readAsText(file);
    filereader.onload = twoD;
    function twoD(){

        let lines = filereader.result.split("\n");
        for (var i = 0; i < lines.length; i++) {
            lines[i] = lines[i].split(",");
        }


        console.table(lines);
        main(lines);
        locationCounter(lines);
        typesCounter(lines);
        totalAmount(lines);
        averageAmount(lines);
        maximumAmount(lines);
        minimumAmount(lines);
        observation (lines);
        present (lines);

    }
}

function main(array){

    let all = locationCounter(array) + typesCounter(array) + totalAmount(array) + averageAmount(array) + maximumAmount(array) +
        minimumAmount(array) + observation (array);
    let statik=document.getElementById("statics");
    statik.innerHTML = all;
    return all;

}

function locationCounter(array) {
    let osMount=0;
    let haMount =0;
    let freMount =0;
    let staMount =0;
    for(let i = 0; i < array.length; i++) {
        if (array[i][2] == "Oslo"){
            osMount += parseInt(array[i][3]);
        }else if (array[i][2] == "Halden"){
            haMount+= parseInt(array[i][3]);
        }else if (array[i][2] == "Fredrikstad"){
            freMount += parseInt(array[i][3]);
        }else{
            staMount += parseInt(array[i][3]);
        }
    }
    const loca = "The total number of transaction for" + "<br/>" + "Oslo is: " + osMount + "<br/>" +
        "Halden is: " + haMount + "<br/>" + "Fredrikstad: " + freMount + "<br/>" +
        "Stavanger is: " + staMount+ "<br/>";
    console.log("The total number of transaction for Oslo is: " + osMount);
    console.log("The total number of transaction for Halden is: " + haMount);
    console.log("The total number of transaction for Fredrikstad: " + freMount);
    console.log("The total number of transaction for Stavanger is: " + staMount);
    return loca ;
}

function typesCounter(array) {
    let entertainmentMount=0;
    let foodMount =0;
    let transportationMount =0;

    for(let i = 0; i < array.length; i++) {
        if (array[i][1] == "Entertainment"){
            entertainmentMount += parseInt(array[i][3]);
        }else if (array[i][1] == "Food"){
            foodMount += parseInt(array[i][3]);
        }else{
            transportationMount += parseInt(array[i][3]);
        }
    }
    const typ= "The total number of transaction for" + "<br/>" + "Entertainment is: " + entertainmentMount + "<br/>"
        + "for Food is: " + foodMount + "<br/>" + "for Transportation: " + transportationMount + "<br/>"
    console.log("The total number of transaction for Entertainment is: " + entertainmentMount);
    console.log("The total number of transaction for Food is: " + foodMount);
    console.log("The total number of transaction for Transportation: " + transportationMount);
    return typ
}

function totalAmount(array) {
    let total=0;
    for (i = 0; i < array.length; i++) {
        total += parseInt(array[i][3]);
    }
    let tot = "The total amount for all transactions is " + total + "<br/>";
    console.log("The total amount for all transactions is " + total);
    return tot
}

function averageAmount(array){
    let total = 0;
    let elementAmount = array.length;
    for(let i = 0; i < array.length; i++){
        total += parseInt(array[i][3]);
    }
    let average = total/elementAmount;
    const aver = "The avrege amount for all transactions is " + average + "<br/>";
    console.log("The avrege amount for all transactions is " + average);
    return aver;
}

function maximumAmount(array){
    let amount =[];
    for (let i = 0; i < array.length; i++){
        amount.push(array[i][3]);
    }
    let maximum = Math.max.apply(null, amount);
    const max = "The maximum amount for all transactions is " + maximum + "<br/>";
    console.log("The maximum amount for all transactions is " + maximum);
    return max;
}

function minimumAmount(array){
    let amount =[];
    for (let i = 0; i < array.length; i++){
        amount.push(array[i][3]);
    }
    let minimum = Math.min.apply(null, amount);
    const min ="The minimum amount for all transactions is " + minimum + "<br/>";
    console.log("The minimum amount for all transactions is " + minimum);
    return min;
}

function observation(array) {
    let places=[];
    for(let i = 0; i < array.length; i++) {
        places.push(array[i][0]);
    }
    let date1 = new Date(places[0]);
    let date2 = new Date(places[15]);
    let diffTime = Math.abs(date2 - date1);
    let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const obs= "The total duration of the observation period in days is " + diffDays + "<br/>";
    console.log("The total duration of the observation period in days is " + diffDays);
    return obs;
}

function present (array) {
    var table = document.getElementById("table");
    for (var i = 0; i < array.length; i++) {
        var row = table.insertRow(-1);
        var cells = array[i];
        cells.unshift([i + 1]);
        for (j = 0; j < cells.length; j++) {
            var cell = row.insertCell(-1);
            cell.innerHTML = cells[j];

        }

    }

}